﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;


//TODO: Add a reference to the IBM.Broker.Plugin.dll assembly which is in the "<MessageBrokerInstallPath>\bin" folder
using IBM.Broker.Plugin;
using System.Diagnostics;
using System.IO;
using System.Globalization;

namespace CreatePDF
{
    /// <summary>
    /// CreateNode Class
    /// </summary>
    public class CreateNode : NBComputeNode
    {

        #region

        //Variables utilizadas para guardar la informacion proveniente en la entrada del nodo NetCompute
        public static string strDsNo = "";
        public static string strNombres = "";
        public static string strCedula = "";
        public static string strFechaIngreso = "";
        public static string strCargo = "";
        public static string strTipoContrato = "";
        public static string strCorreoElectronico = string.Empty;
        public static string strAsignacionMensual = "";
        public static string strSolicitud = "";
        public static string strDestino = "";

        //Variables utilizadas para guardar la informacion que conforma el certificado laboral
        public static string strSeccion0 = "ST";
        public static string strSeccion1 = "Bogotá, D.C.,                            "+ DateTime.Today.ToLongDateString()+"                  DS No.   ";
        public static string strSeccion2 = "CARACOL TELEVISIÓN S.A.";
        public static string strSeccion3 = "HACE CONSTAR";
        public static string strSeccion4 = "Que los siguientes datos han sido verificados en el Departamento de Salarios";
        public static string strSeccion4_1 = "de la Gerencia Administrativa:";
        public static string strSeccion5 = "Nombre";
        public static string strSeccion6 = "Cédula de Ciudadanía";
        public static string strSeccion7 = "Fecha de Ingreso";
        public static string strSeccion8 = "Cargo";
        public static string strSeccion9 = "Tipo de Contrato";
        public static string strSeccion10 = "Asignación Mensual";
        public static string strSeccion11 = "Se Expide a Solicitud de";
        public static string strSeccion12 = "Con Destino a";
        public static string strSeccion13 = "Fecha de Expedición";
        public static string strSeccion14 = "Atentamente,";
        public static string strSeccion15 = "DEPARTAMENTO DE SALARIOS";
        public static string strFirma1 = "";
        public static string strFirma2 = "EDILMA BARRERO CHAVEZ";
        public static string strFirma3 = "JEFE DE SALARIOS";
        #endregion
        /// <summary>
        /// Metodo que se ejecuta cuando ingresa al nodo NetCompute
        /// </summary>
        /// <param name="inputAssembly">Objeto donde se encuentran las variables de entrada</param>
        public override void Evaluate(NBMessageAssembly inputAssembly)
        {
            NBOutputTerminal outTerminal = OutputTerminal("Out");
            NBMessage inputMessage = inputAssembly.Message;

            // Create a new empty message, ensuring it is disposed after use
            using (NBMessage outputMessage = new NBMessage())
            {
                NBMessageAssembly outAssembly = new NBMessageAssembly(inputAssembly, outputMessage);                
                NBElement inputRoot = inputAssembly.Environment.RootElement;
                
                //Lee el mensaje de entrada y los guardas en variables locales
                strDsNo = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["DsNo"].ValueAsString;
                strNombres = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["Nombres"].ValueAsString;
                strCedula = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["Cedula"].ValueAsString;
                strFechaIngreso = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["FechaIngreso"].ValueAsString;
                strCargo = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["Cargo"].ValueAsString;
                strTipoContrato = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["TipoContrato"].ValueAsString;
                strAsignacionMensual = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["AsignacionMensual"].ValueAsString;                                                                                                                                                                   
                strSolicitud = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["Solicitud"].ValueAsString;
                strDestino = inputAssembly.Message.RootElement["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralPdfRequest"]["CertificadoLaboral"]["Destino"].ValueAsString;               
                NBElement outputRoot = outputMessage.RootElement;                
                // Optionally copy message headers, remove if not needed
                CopyMessageHeaders(inputRoot, outputRoot);
                #region Fragmento de codigo que genera la respuesta para guardarse en MQ para posterior respuesta en CH2 en SOAP Reply
                
                
                
                outputRoot.CreateLastChildUsingNewParser(NBParsers.XMLNSC.ParserName);
                outputRoot["XMLNSC"].CreateFirstChild("http://www.w3.org/2003/05/soap-envelope", "Envelope");
                outputRoot["XMLNSC"]["Envelope"].CreateFirstChild("http://www.w3.org/2003/05/soap-envelope", "Body");
                outputRoot["XMLNSC"]["Envelope"]["Body"].CreateFirstChild("http://www.caracoltv.com.co/nomina/xcalibur/crearcertificadolaboralpdf/", "CrearCertificadoLaboralResponse");
                string strFile = Convert.ToBase64String(CrearPDF(strDsNo, strNombres, strCedula, strFechaIngreso, strCargo, strTipoContrato, strAsignacionMensual, strSolicitud, strDestino));
                outputRoot["XMLNSC"]["Envelope"]["Body"]["CrearCertificadoLaboralResponse"].CreateFirstChild(null, "ArchivoPdf").SetValue(strFile);
                
                #endregion UserCode
                // Change the following if not propagating message to the 'Out' terminal
                outTerminal.Propagate(outAssembly);
            }
        }

        #region CopyMessageHeaders
        /// <summary>
        /// CopyMessageHeaders Method
        /// </summary>
        /// <param name="inputRoot"></param>
        /// <param name="outputRoot"></param>
        private static void CopyMessageHeaders(NBElement inputRoot, NBElement outputRoot)
        {
            // Iterate though the headers under the root element
            foreach (NBElement currentElement in inputRoot)
            {
                // Stop before the lastchild which is the body of the message
                if (currentElement.NextSibling != null)
                {
                    // Copy the header and add it to the output message
                    outputRoot.AddLastChild(currentElement);
                }
            }
        }
        #endregion

        /// <summary>
        /// Metodo que genera el archivo PDF
        /// </summary>
        /// <param name="DsNo">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="Nombres">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="Cedula">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="FechaIngreso">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="Cargo">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="TipoContrato">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="AsignacionMensual">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="Solicitud">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <param name="Destino">Variable proveniente de mensaje de entrada utilizada para armar el archivo PDF</param>
        /// <returns>Arreglo de bytes que contiene el archivo</returns>
        private static byte[] CrearPDF(string DsNo, string Nombres, string Cedula, string FechaIngreso, string Cargo, string TipoContrato, string AsignacionMensual, string Solicitud, string Destino)
        {
            PdfDocument pdf = new PdfDocument();
            pdf.Info.Title = "Certificado Laboral " + strCedula;
            PdfPage pdfPage = pdf.AddPage();
            XGraphics graph = XGraphics.FromPdfPage(pdfPage);
            XFont font = new XFont("Verdana", 8, XFontStyle.Regular);
            XFont fontTitulo = new XFont("Verdana", 10, XFontStyle.Bold);

            double iniciox = 100;
            double inicioy = 90;
            graph.DrawString(strSeccion0 , font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 10;
            graph.DrawString(strSeccion1 + " " + DsNo, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 35;
            graph.DrawString(strSeccion2, fontTitulo, XBrushes.Black, new XRect(0, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopCenter);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion3, font, XBrushes.Black, new XRect(0, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopCenter);
            iniciox = iniciox + 50;
            graph.DrawString(strSeccion4, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion4_1, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 50;

            
            graph.DrawString(strSeccion5 + "                         :" + Nombres, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion6 + "    :" + Cedula, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion7 + "            :" + FechaIngreso, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion8 + "                            :" + Cargo, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion9 + "             :" + TipoContrato, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;

            CultureInfo us = new CultureInfo("en-US");
            // Display i formatted as currency for us.
           int Valor= Convert.ToInt32( AsignacionMensual);

           graph.DrawString(strSeccion10 + "         :" + Valor.ToString("c", us), font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 40;
            graph.DrawString(strSeccion11 + "    :" + Solicitud, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion12 + "                  :" + Destino, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion13 + "         :" + DateTime.Today.ToLongDateString(), font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 120;
            graph.DrawString(strSeccion14, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion15, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 20;
            graph.DrawImage(XImage.FromFile(@"C:\CrearPDF\firma.jpg"), new XRect(inicioy, iniciox, 175,85));
            iniciox = iniciox + 160;
            graph.DrawString(strFirma3, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 130;


            if (!Directory.Exists(@"C:\CrearPDF"))
                Directory.CreateDirectory(@"C:\CrearPDF");
            pdf.SecuritySettings.UserPassword = strCedula;
            if (File.Exists(@"C:\CrearPDF\firstpage.pdf"))
                File.Delete(@"C:\CrearPDF\firstpage.pdf");
            string pdfFilename = @"C:\CrearPDF\firstpage.pdf";
            pdf.Save(pdfFilename);            
            byte[] bytes =File.ReadAllBytes(@"C:\CrearPDF\firstpage.pdf");
            
            
            return bytes;
        }
    }
}