﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.IO;
using System.Diagnostics;

namespace PruebaDll
{
    class Program
    {
        #region

        public static string strDsNo = "";
        public static string strNombres = "";
        public static string strCedula = "123";
        public static string strFechaIngreso = "";
        public static string strCargo = "";
        public static string strTipoContrato = "";
        public static string strAsignacionMensual = "";
        public static string strSolicitud = "";
        public static string strDestino = "";


        public static string strSeccion1 = "Bogotá, D.C.";
        public static string strSeccion2 = "CARACOL TELEVISIÓN S.A.";
        public static string strSeccion3 = "HACE CONSTAR";
        public static string strSeccion4 = "Que los siguientes datos han sido verificados en el Departamento de Salarios de la Gerencia Administrativa:";
        public static string strSeccion5 = "Nombre";
        public static string strSeccion6 = "Cédula dde Ciudadanía";
        public static string strSeccion7 = "Fecha de Ingreso";
        public static string strSeccion8 = "Cargo";
        public static string strSeccion9 = "Tipo de Contrato";
        public static string strSeccion10 = "Asignación Mensual";
        public static string strSeccion11 = "Se expide a solicitud de";
        public static string strSeccion12 = "Con destino a";
        public static string strSeccion13 = "Fecha de Expedición";
        public static string strSeccion14 = "Atentamente,";
        public static string strSeccion15 = "DEPARTAMENTO DE SALARIOS";
        public string strFirma = "";

        #endregion
        static void Main(string[] args)
        {
            crear();
        }

        private static void CrearPDF()
        {
            PdfDocument pdf = new PdfDocument();

            pdf.Info.Title = "My First PDF";
            PdfPage pdfPage = pdf.AddPage();
            XGraphics graph = XGraphics.FromPdfPage(pdfPage);
            XFont font = new XFont("Verdana", 20, XFontStyle.Bold);
            graph.DrawString("This is my first PDF document", font, XBrushes.Black, new XRect(0, 0, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.Center);
             string pdfFilename = "D:\\firstpage.pdf";
            pdf.SecuritySettings.UserPassword = "123";
            pdf.SecuritySettings.OwnerPassword = "123";

           

            using (MemoryStream ms = new MemoryStream())
            {
                pdf.Save(ms, false);
                byte[] buffer = new byte[ms.Length];
                ms.Seek(0, SeekOrigin.Begin);
                ms.Flush();
                ms.Read(buffer, 0, (int)ms.Length);
            }
            pdf.Save(pdfFilename);
            Process.Start(pdfFilename);
            //MemoryStream stream = new MemoryStream();
            //pdf.Save(stream, false);
            //byte[] bytes = stream.ToArray();

            //return bytes;
        }


        private static void crear()
        {
            PdfDocument pdf = new PdfDocument();
            pdf.Info.Title = "Certificado Laboral " + strCedula;
            PdfPage pdfPage = pdf.AddPage();
            XGraphics graph = XGraphics.FromPdfPage(pdfPage);
            XFont font = new XFont("Verdana", 12, XFontStyle.Regular);
            XFont fontTitulo = new XFont("Verdana", 14, XFontStyle.Bold);
            
            double iniciox = 110;
            double inicioy = 40;
            graph.DrawString(strSeccion1, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 50;
            graph.DrawString(strSeccion2, fontTitulo, XBrushes.Black, new XRect(0, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopCenter);
            iniciox = iniciox + 20;
            graph.DrawString(strSeccion3, font, XBrushes.Black, new XRect(0, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopCenter);
            iniciox = iniciox + 50;
            graph.DrawString(strSeccion4, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 50;
            graph.DrawString(strSeccion5, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion6, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion7, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion8, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion9, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion10, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 60;
            graph.DrawString(strSeccion11, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion12, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion13, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion14, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;
            graph.DrawString(strSeccion15, font, XBrushes.Black, new XRect(inicioy, iniciox, pdfPage.Width.Point, pdfPage.Height.Point), XStringFormats.TopLeft);
            iniciox = iniciox + 30;

            pdf.SecuritySettings.UserPassword = strCedula;
            //pdf.SecuritySettings.OwnerPassword = ;

            string pdfFilename = "D:\\firstpage.pdf";
            pdf.Save(pdfFilename);

            //Process.Start(pdfFilename);
        }
    }
}
